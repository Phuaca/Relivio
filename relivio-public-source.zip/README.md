# Relivio

Relivio is a HackRift 2025 team prototype for sharing surplus food. Vendors can create a pickup listing with a photo, quantity and location. Organisations can browse sample donations in a feed or on a map and try the pickup flow.

[Try the team's browser demo](https://relivio.netlify.app/) · [HackRift submission and team credits](https://devpost.com/software/bytelabs-food-waste)

## My contribution

I built the browser photo capture flow for vendor listings. In our recorded local demo, I checked that the captured photo appeared in the vendor's listing.

## Run locally

From this folder on Windows, start a local server with Python:

```powershell
py -m http.server 8000 --bind 127.0.0.1
```

Then open [http://127.0.0.1:8000/](http://127.0.0.1:8000/). The map, address lookup and externally hosted assets need an internet connection.

## Project details

- The prototype uses HTML, CSS, JavaScript and Leaflet with OpenStreetMap. It runs directly in the browser and uses sample data. Demo changes reset when you refresh.
- The photo control uses the browser's image picker. A supported phone can open the camera from the picker. On a desktop, choose an existing image.
- ByteLabs built Relivio for HackRift 2025. The submission credits Jordan Yeo and Phua Cheng Ann.
